const Words = require("../models/Words");
const MAX_GUESSES = 7;
const game = {
    letters: ['A', 'B', 'C', 'D', 'E',
    'F', 'G', 'H', 'I', 'J', 'K',
    'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
    'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
    selectedLetters: [],
    message: "",
    hangManStages: [],
    status: "",
    active: true,
    hangMan: "",
    maskedWord: "",
    numRight:0,
    numWrong:0,
    hint: "",
    hintNotActive: true,
};


exports.setupGame = (req, res,next) => {
    console.log("in setup")

    const words = new Words();
    const randomWordData = words.getRandomWord();
    game.numRight = 0;
    game.numWrong = 0;
    game.status = "";
    game.message ="";
    game.active = true;
    game.hintNotActive = true;
    game.guessesLeft = MAX_GUESSES;
    game.maskedWord = '_ '.repeat(randomWordData.word.length).trim();
    game.hint = randomWordData.hint
    game.letters = [
        'A', 'B', 'C', 'D', 'E', 'F',
        'G', 'H', 'I', 'J', 'K', 'L',
        'M', 'N', 'O', 'P', 'Q', 'R', 'S',
        'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    game.hangManStages = [
        '/imgs/1.png', '/imgs/2.png', '/imgs/3.png',
        '/imgs/4.png', '/imgs/5.png', '/imgs/6.png',
        '/imgs/7.png', '/imgs/8.png', '/imgs/gameOver.png',
        '/imgs/gameOverWin.webp',
    ]
    game.hangMan = game.hangManStages[0];
    console.log(game.hangMan)
    game.selectedLetters = [];
    game.word = randomWordData.word;
    res.render('main-layout', game);
};

exports.guess = (req, res, next) => {
    console.log("in guess");
    const guess = req.body.letter.toLowerCase();
    console.log(guess)
    const word = game.word;
    console.log(word)
    game.letters = game.letters.filter(letter => letter !== guess.toUpperCase());
    console.log(game.letters)

    let {maskedWord, selectedLetters} = game;
    selectedLetters.push(guess);
    if (word.includes(guess)) {
        const newMaskedWord = word.split('').map((char, i) => {
            if (char === guess || maskedWord[i*2] !== '_') {
                return char;
            } else {
                return '_';
            }
        }).join(' ');
        game.maskedWord = newMaskedWord;
        game.numRight++
    } else {
        game.guessesLeft --
        game.numWrong ++
    }
    let temp = game.numWrong
    if (!game.maskedWord.includes('_')) {
        console.log("in won")
        game.active = false;
        game.message = "You Have Won"
        game.status = game.hangManStages[8]
    } else if (game.numWrong >= MAX_GUESSES) {
        console.log("in lost")
        game.active = false;
        game.message = "You Have Lost"
        game.status = game.hangManStages[9]
    }

    game.hangMan = game.hangManStages[game.numWrong];
    game.numWrong = temp
    res.render('main-layout', game)
};

exports.hint = (req, res, next) => {
    game.hintNotActive = false;
    res.render('main-layout', game)
};












