const express = require('express');
const router = express.Router();
const path = require('path');
const Words = require('../models/Words');
const gameController = require('../controllers/game');
router.get('/home', gameController.setupGame );
router.post('/home', gameController.guess );
router.post('/hint', gameController.hint );
router.post('/newGame', gameController.setupGame);

module.exports = router;